package random;

public class Operator {
	public static void main(String[] args) {
	     int x=-10;
	     int y=x>>>1;
	     System.out.println(y);
	}
}
