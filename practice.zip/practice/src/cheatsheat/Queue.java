package cheatsheat;

public class Queue {

	public static void main(String[] args) {
		int[] gas = {4, 5, 7, 4};
		int[] cost= {6, 6, 3, 5};
		int res1=gasStation(gas,cost);
		System.out.println(res1);
	}

	private static int gasStation(int[] gas, int[] cost) {
		int totalgas=0,totalCost=0,
		for(int i=0;i<gas.length;i++) {
			
		}
	}

}
