package set18;

public class CheckSum {

	public static void main(String[] args) {
		
	}

}
