package test;

public class Demo {

	public static void main(String[] args) {
		System.out.println("hello one...");
		//TTest t=new TTest();
	}

}

class TTest {
	static {
		System.out.println("hoooo");
	}
}
