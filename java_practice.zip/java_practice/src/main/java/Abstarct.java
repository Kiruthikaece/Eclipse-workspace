
public class Abstarct {

	public static void main(String[] args) {
		//Test test=new Test();
		
	}

}


abstract class Test11 {
	
	final void testing() {
		System.out.println("Test implement class");
	}
	abstract void print();
	
	
	 abstract  void calculate();
}

//class TestImp extends Test11 {
//	void print() {
//		System.out.println("Test implement class");
//	}
//}