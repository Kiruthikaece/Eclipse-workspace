
public class MultipleOfThree {

	public static void main(String[] args) {
		
		int[][] mat= {{1,2,3},{4,5,6},{7,8,9}};
		
		
//				 int temp=mat[0][0];
//				 mat[0][0]=mat[2][2];
//				 mat[2][2]=temp;
//				 
//				 int temp2=mat[0][2];
//				 mat[0][2]=mat[2][0];
//				 mat[2][0]=temp2;
//				 
//				 int n=mat.length;
//				 for(int i=0;i<mat.length;i++) {
//					 for(int j=0;j<mat.length;j++) {
//				      if(i==0 && j==0 || i==0 && j==n-1 || i==n-1 && j==0 || i==n-1 &&j==n-1) {
//				    	   int temp=mat[i][j];
//				    	   mat[i][j]=mat[]
//				      }
//			 }
//					
//		 }
//
	}
}
