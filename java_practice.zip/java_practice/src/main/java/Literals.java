

public class Literals {
  public static void main(String[] args) {
	  System.out.println("\t"+"Hello");
	  System.out.println("\"Hello\"");
	  System.out.println("\'Hello\'");
	  System.out.println("\n-Hello");
	  System.out.println("Hello\rworld\ruuuu");
	  System.out.println("Hello\fworld");
	  System.out.println("Hello\bworld");
	  
	  long n=99_00_99_00_99L;
	  System.out.println(n);
	  
	  float f=10.00F;
	  String s="eeee";
	  char ch='r';
	  
	  int x=-12%-5;
	  System.out.println(x);
	  
	  int y=12%-5;
	  System.out.println(y);
	  
	  
	  int a=-12/-5;
	  System.out.println(a);
	  
	  int b=12/-5;
	  System.out.println(b);
	  
	  
  }
}
