import test.UnconditionalControlStmt;

public class AccessModifier extends UnconditionalControlStmt{

	public static void main(String[] args) {
		
		AccessModifier obj=new AccessModifier();
		obj.printProtected();
	}

}
